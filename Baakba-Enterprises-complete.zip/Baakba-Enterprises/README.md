# Ba'akba Enterprises

Single-store grocery e-commerce starter for Jos North, Plateau State, Nigeria.

## Stack
Next.js + TypeScript + Tailwind CSS + Supabase/PostgreSQL + Paystack.

## Setup
1. Create a Supabase project.
2. Run `supabase/migrations/001_schema.sql` in the Supabase SQL editor.
3. Run `supabase/seed.sql`.
4. Copy `.env.example` to `.env.local` and fill in Supabase and Paystack values.
5. Install packages: `npm install`
6. Start: `npm run dev`

## Important
The included payment code is structured around server-side Paystack initialization, webhook signature verification, and a transactional `confirm_order_payment` database function. Before accepting live money, complete a production security review, configure Paystack webhook URLs, test with Paystack test keys, and verify the exact deployed Supabase RLS/auth setup.

## Paystack webhook
Set the Paystack webhook endpoint to:
`https://YOUR_DOMAIN/api/paystack/webhook`

## Admin
Promote a trusted user to ADMIN only from the Supabase server/database side. Never expose the service-role key to the browser.


## Ba'akba v3 hardening checklist

### Required environment variables
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `PAYSTACK_SECRET_KEY`
- `NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY`
- `NEXT_PUBLIC_SITE_URL`

Never expose `SUPABASE_SERVICE_ROLE_KEY` or `PAYSTACK_SECRET_KEY` to browser code.

### Local verification
```bash
npm install
npm run typecheck
npm run build
npm run dev
```

Health check:
`/api/health`

### Before going live
1. Apply all Supabase migrations in order.
2. Create an admin account and assign the ADMIN role through the protected database function/process.
3. Configure Paystack webhook URL to the deployed `/api/paystack/webhook` route if that route exists in the project.
4. Configure Paystack callback/redirect URL to the deployed checkout confirmation page.
5. Test successful, failed, cancelled and duplicate payment callbacks.
6. Test stock cannot go below zero under concurrent purchases.
7. Test guest cart -> login/register -> cart merge.
8. Test delivery and pickup orders separately.
9. Test invalid/expired coupons and coupon rollback on cancellation.
10. Verify every admin mutation is protected by server-side role checks and audited.
11. Add production rate limiting/WAF rules at the hosting layer or a trusted rate-limit service.
12. Configure backups and database point-in-time recovery.
13. Configure a custom domain and HTTPS on Vercel.

## v4 additions
- Protected admin shell/navigation
- Product create/edit/deactivate flows
- Server-side product validation
- Admin inventory adjustment endpoint
- Admin order status management
- Admin order detail view

## v5 additions
- Admin categories management
- Delivery-zone creation foundation
- Coupon creation foundation
- Homepage banner creation foundation
- Shared admin authorization helper
- Additional operational indexes

## v6 additions
- Customer product search and price sorting
- Wishlist API and UI
- Saved-address creation UI/API
- Order reorder-to-cart endpoint
- Customer shopping navigation improvements


## FINAL release additions
- Mobile-first storefront homepage
- Category browsing and product discovery
- Verified-purchaser review submission with admin moderation
- Coupon validation endpoint
- Wishlist, addresses and reorder foundations retained
- Admin review moderation
- Final deployment/testing checklist retained in this repository

## Important
This source package is a complete development release, not a guarantee of a live production deployment. Before accepting real customer payments, run `npm run typecheck` and `npm run build`, apply Supabase migrations, configure Paystack webhooks/callbacks, verify environment variables, and perform a real staging payment test.
