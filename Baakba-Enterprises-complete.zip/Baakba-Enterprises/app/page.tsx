import Link from "next/link";
import { supabaseAdmin } from "@/lib/supabase-admin";

export default async function Home() {
  const db=supabaseAdmin();
  const [{data:banners},{data:products},{data:categories}] = await Promise.all([
    db.from("homepage_banners").select("*").eq("is_active",true).order("created_at",{ascending:false}).limit(3),
    db.from("products").select("id,name,slug,price,unit,product_images(url,sort_order)").eq("is_active",true).order("created_at",{ascending:false}).limit(8),
    db.from("categories").select("id,name,slug").eq("is_active",true).order("name").limit(12),
  ]);
  return <main>
    <section className="mx-auto max-w-6xl px-4 pt-8">
      <div className="rounded-2xl bg-black px-6 py-12 text-white sm:px-10">
        <p className="text-sm font-medium opacity-80">Ba&apos;akba Enterprises</p>
        <h1 className="mt-2 max-w-2xl text-4xl font-bold tracking-tight sm:text-5xl">Everyday groceries, made easy.</h1>
        <p className="mt-4 max-w-xl text-white/75">Shop groceries online in Jos North and choose convenient home delivery or store pickup.</p>
        <Link href="/products" className="mt-7 inline-block rounded-xl bg-white px-5 py-3 font-semibold text-black">Shop now</Link>
      </div>
    </section>
    {!!banners?.length && <section className="mx-auto max-w-6xl px-4 py-6 grid gap-4 md:grid-cols-3">{banners.map(b=><div key={b.id} className="rounded-xl border bg-white p-5"><h2 className="font-bold">{b.title}</h2><p className="mt-1 text-sm text-gray-600">{b.subtitle}</p></div>)}</section>}
    <section className="mx-auto max-w-6xl px-4 py-4"><h2 className="text-2xl font-bold">Shop by category</h2><div className="mt-4 flex gap-3 overflow-x-auto pb-2">{categories?.map(c=><Link key={c.id} href={`/products?category=${c.id}`} className="shrink-0 rounded-full border bg-white px-4 py-2 text-sm">{c.name}</Link>)}</div></section>
    <section className="mx-auto max-w-6xl px-4 py-8"><div className="flex items-center justify-between"><h2 className="text-2xl font-bold">Popular groceries</h2><Link href="/products" className="text-sm font-semibold">View all</Link></div><div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">{products?.map(p=><Link key={p.id} href={`/products/${p.slug}`} className="rounded-xl border bg-white p-3"><div className="aspect-square rounded-lg bg-gray-100 overflow-hidden">{p.product_images?.[0]?.url&&<img src={p.product_images[0].url} alt={p.name} className="h-full w-full object-cover"/>}</div><h3 className="mt-3 font-semibold">{p.name}</h3><p className="text-sm text-gray-500">{p.unit}</p><p className="mt-1 font-bold">₦{Number(p.price).toLocaleString()}</p></Link>)}</div></section>
  </main>
}
