export default function TermsPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-bold">Terms &amp; Conditions</h1>
      <p className="mt-4 text-gray-600">
        Orders are subject to product availability, confirmed pricing, and the
        delivery or pickup options shown during checkout.
      </p>
      <h2 className="mt-8 text-xl font-semibold">Orders and payment</h2>
      <p className="mt-2 text-gray-600">
        Online orders are paid through Paystack. An order becomes payable only
        after the final server-side checkout calculation is completed.
      </p>
      <h2 className="mt-8 text-xl font-semibold">Pickup and delivery</h2>
      <p className="mt-2 text-gray-600">
        Pickup orders are collected from the store according to the pickup
        instructions shown after confirmation. Delivery timing can vary by zone,
        stock availability, traffic, and operating hours.
      </p>
    </main>
  );
}
