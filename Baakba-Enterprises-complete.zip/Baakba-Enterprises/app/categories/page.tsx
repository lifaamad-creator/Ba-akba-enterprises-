import Link from "next/link";
import { supabasePublic } from "@/lib/supabase";
export default async function Categories(){
 const {data}=await supabasePublic().from("categories").select("id,name,slug,description").eq("active",true).order("sort_order");
 return <div className="container" style={{padding:"40px 0"}}><h1>Categories</h1><div className="grid-products" style={{marginTop:20}}>{(data??[]).map(c=><Link className="card" style={{padding:24}} href={`/products?category=${c.slug}`} key={c.id}><div style={{fontSize:40}}>🥫</div><h2 style={{fontSize:20}}>{c.name}</h2><p style={{color:"#64748b"}}>{c.description}</p></Link>)}</div></div>
}