"use client";
import {useEffect,useState} from "react";
import Link from "next/link";

export default function Products(){
 const [items,setItems]=useState<any[]>([]),[q,setQ]=useState(""),[sort,setSort]=useState("name"),[loading,setLoading]=useState(true);
 async function load(){setLoading(true);const p=new URLSearchParams();if(q)p.set("q",q);p.set("sort",sort);const r=await fetch(`/api/products?${p}`);setItems(await r.json());setLoading(false)}
 useEffect(()=>{const t=setTimeout(load,250);return()=>clearTimeout(t)},[q,sort]);
 return <main className="mx-auto max-w-6xl px-4 py-8"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><h1 className="text-3xl font-bold">Shop groceries</h1><select value={sort} onChange={e=>setSort(e.target.value)} className="rounded-lg border px-3 py-2"><option value="name">Name</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option></select></div><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search groceries..." className="mt-5 w-full rounded-xl border px-4 py-3"/>{loading?<p className="py-10">Loading...</p>:items.length===0?<p className="py-10 text-gray-500">No products found.</p>:<div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">{items.map(p=><Link key={p.id} href={`/products/${p.slug}`} className="rounded-xl border bg-white p-3 hover:shadow-sm"><div className="aspect-square rounded-lg bg-gray-100 overflow-hidden">{p.product_images?.[0]?.url&&<img src={p.product_images[0].url} alt={p.name} className="h-full w-full object-cover"/>}</div><h2 className="mt-3 font-semibold">{p.name}</h2><p className="text-sm text-gray-500">{p.unit}</p><p className="mt-1 font-bold">₦{Number(p.price).toLocaleString()}</p></Link>)}</div>}</main>
}
