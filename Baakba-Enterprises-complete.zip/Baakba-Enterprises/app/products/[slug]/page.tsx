import { notFound } from "next/navigation";
import { supabasePublic } from "@/lib/supabase";
import { formatNaira } from "@/lib/money";

import ProductReviews from "@/components/ProductReviews";
export default async function Product({params}:{params:Promise<{slug:string}>}) {
  const {slug}=await params;
  const {data:p}=await supabasePublic().from("products").select("*").eq("slug",slug).eq("active",true).single();
  if(!p) notFound();
  return <div className="container" style={{padding:"40px 0"}}>
    <div className="card" style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:35,padding:25}}>
      <div style={{minHeight:380,borderRadius:18,background:"#f1f5f2",display:"grid",placeItems:"center",fontSize:90}}>🛒</div>
      <div><p style={{color:"#166534",fontWeight:800}}>GROCERY</p><h1>{p.name}</h1><p style={{color:"#64748b",lineHeight:1.6}}>{p.description}</p><div style={{fontSize:30,fontWeight:900}}>{formatNaira(p.price)}</div><p>Sold per <strong>{p.selling_unit}</strong></p><p>{p.stock_quantity>0 ? "In stock" : "Out of stock"}</p><button className="btn btn-primary" disabled={!p.stock_quantity}>Add to cart</button></div>
    </div>
  </div>
}