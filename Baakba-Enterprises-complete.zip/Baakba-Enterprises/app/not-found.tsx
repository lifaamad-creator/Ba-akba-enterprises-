export default function NotFound() {
  return (
    <main className="mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="text-3xl font-bold">Page not found</h1>
      <p className="mt-2 text-gray-600">The page you requested does not exist.</p>
      <a href="/" className="mt-6 inline-block rounded-lg bg-black px-5 py-3 text-white">
        Back to store
      </a>
    </main>
  );
}
