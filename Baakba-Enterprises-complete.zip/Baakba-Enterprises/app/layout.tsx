import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "Ba'akba Enterprises | Groceries in Jos North",
  description: "Shop groceries online from Ba'akba Enterprises in Jos North, Plateau State.",
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>
    <header style={{background:"white",borderBottom:"1px solid #e2e8e3",position:"sticky",top:0,zIndex:20}}>
      <div className="container" style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"15px 0",gap:16}}>
        <Link href="/" style={{fontWeight:900,fontSize:22,color:"#166534"}}>Ba'akba Enterprises</Link>
        <nav style={{display:"flex",gap:16,fontSize:14,fontWeight:700}}>
          <Link href="/products">Shop</Link><Link href="/categories">Categories</Link><Link href="/cart">Cart</Link><Link href="/account">Account</Link>
        </nav>
      </div>
    </header>
    <main>{children}</main>
    <footer style={{marginTop:60,padding:"35px 0",background:"#12351f",color:"white"}}>
      <div className="container"><strong>Ba'akba Enterprises</strong><p style={{opacity:.8}}>Groceries • Jos North, Plateau State, Nigeria</p></div>
    </footer>
  </body></html>
}