import Link from "next/link";
import { requireUser } from "@/lib/auth";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const role = String(user.profile?.role ?? user.role ?? "").toUpperCase();
  if (role !== "ADMIN") {
    return (
      <main className="mx-auto max-w-xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold">Admin access required</h1>
        <p className="mt-2 text-gray-600">This area is restricted to store administrators.</p>
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 py-6">
        <nav className="mb-6 flex flex-wrap gap-2 rounded-xl border bg-white p-3 text-sm">
          <Link className="rounded-lg px-3 py-2 hover:bg-gray-100" href="/admin">Overview</Link>
          <Link className="rounded-lg px-3 py-2 hover:bg-gray-100" href="/admin/products">Products</Link><Link className="rounded-lg px-3 py-2 hover:bg-gray-100" href="/admin/categories">Categories</Link>
          <Link className="rounded-lg px-3 py-2 hover:bg-gray-100" href="/admin/orders">Orders</Link>
          <Link className="rounded-lg px-3 py-2 hover:bg-gray-100" href="/admin/delivery">Delivery</Link>
          <Link className="rounded-lg px-3 py-2 hover:bg-gray-100" href="/admin/coupons">Coupons</Link>
          <Link className="rounded-lg px-3 py-2 hover:bg-gray-100" href="/admin/banners">Banners</Link><Link className="rounded-lg px-3 py-2 hover:bg-gray-100" href="/admin/reviews">Reviews</Link>
        </nav>
        {children}
      </div>
    </div>
  );
}
