"use client";
import {useEffect,useState} from "react";
export default function Banners(){
 const [items,setItems]=useState<any[]>([]);const [title,setTitle]=useState("");const [subtitle,setSubtitle]=useState("");const [image,setImage]=useState("");
 async function load(){const r=await fetch("/api/admin/banners");setItems(await r.json())}useEffect(()=>{load()},[]);
 async function add(){const r=await fetch("/api/admin/banners",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({title,subtitle,image_url:image})});if(!r.ok)alert(await r.text());else{setTitle("");setSubtitle("");setImage("");load()}}
 return <main><h1 className="text-2xl font-bold">Homepage banners</h1><div className="mt-5 grid gap-2 rounded-xl border bg-white p-4"><input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} className="rounded-lg border px-3 py-2"/><input placeholder="Subtitle" value={subtitle} onChange={e=>setSubtitle(e.target.value)} className="rounded-lg border px-3 py-2"/><input placeholder="Image URL (Supabase Storage)" value={image} onChange={e=>setImage(e.target.value)} className="rounded-lg border px-3 py-2"/><button onClick={add} className="rounded-lg bg-black px-4 py-2 text-white">Add banner</button></div><div className="mt-6 rounded-xl border bg-white">{items.map(b=><div key={b.id} className="border-b p-4"><b>{b.title}</b><p className="text-sm text-gray-500">{b.subtitle}</p></div>)}</div></main>
}
