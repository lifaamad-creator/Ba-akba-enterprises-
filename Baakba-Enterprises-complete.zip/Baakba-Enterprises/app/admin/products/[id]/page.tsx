"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";

export default function EditProductPage() {
  const {id}=useParams<{id:string}>(); const router=useRouter();
  const [form,setForm]=useState<any>(null); const [busy,setBusy]=useState(false);
  useEffect(()=>{fetch(`/api/admin/products/${id}`).then(r=>r.json()).then(setForm)},[id]);
  if(!form) return <p>Loading...</p>;

  async function save(e:React.FormEvent){e.preventDefault();setBusy(true);
    const res=await fetch(`/api/admin/products/${id}`,{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({...form,price:Number(form.price),stock_quantity:Number(form.stock_quantity)})});
    if(!res.ok){alert(await res.text());setBusy(false);return} router.push("/admin/products");
  }
  return <main><h1 className="text-2xl font-bold">Edit product</h1>
    <form onSubmit={save} className="mt-6 grid gap-4 rounded-xl border bg-white p-5 md:max-w-2xl">
      {["name","slug","description","price","stock_quantity","unit","sku"].map(k=><label key={k} className="grid gap-1 text-sm font-medium">{k}
        <input value={form[k]??""} onChange={e=>setForm({...form,[k]:e.target.value})} className="rounded-lg border px-3 py-2"/>
      </label>)}
      <label className="flex gap-2"><input type="checkbox" checked={!!form.is_active} onChange={e=>setForm({...form,is_active:e.target.checked})}/> Active</label>
      <button disabled={busy} className="rounded-lg bg-black px-4 py-3 text-white">{busy?"Saving...":"Save changes"}</button>
    </form>
  </main>;
}
