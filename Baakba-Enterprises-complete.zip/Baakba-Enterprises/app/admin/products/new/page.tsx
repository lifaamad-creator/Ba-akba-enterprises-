"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewProductPage() {
  const router = useRouter();
  const [busy,setBusy]=useState(false);
  const [form,setForm]=useState({name:"",slug:"",description:"",price:"",stock_quantity:"",unit:"piece",sku:"",is_active:true});

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    const res=await fetch("/api/admin/products",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({
      ...form, price:Number(form.price), stock_quantity:Number(form.stock_quantity)
    })});
    if(!res.ok){ alert(await res.text()); setBusy(false); return; }
    router.push("/admin/products");
  }

  return <main>
    <h1 className="text-2xl font-bold">Add product</h1>
    <form onSubmit={submit} className="mt-6 grid gap-4 rounded-xl border bg-white p-5 md:max-w-2xl">
      {[
        ["name","Product name"],["slug","Slug"],["description","Description"],["price","Price (NGN)"],
        ["stock_quantity","Stock quantity"],["unit","Unit"],["sku","SKU"]
      ].map(([key,label])=><label key={key} className="grid gap-1 text-sm font-medium">{label}
        <input required={key!=="description"&&key!=="sku"} value={(form as any)[key]} onChange={e=>setForm({...form,[key]:e.target.value})} className="rounded-lg border px-3 py-2" />
      </label>)}
      <label className="flex gap-2 text-sm"><input type="checkbox" checked={form.is_active} onChange={e=>setForm({...form,is_active:e.target.checked})}/> Active</label>
      <button disabled={busy} className="rounded-lg bg-black px-4 py-3 text-white disabled:opacity-50">{busy?"Saving...":"Save product"}</button>
    </form>
  </main>;
}
