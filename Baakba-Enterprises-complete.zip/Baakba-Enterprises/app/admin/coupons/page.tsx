"use client";
import {useEffect,useState} from "react";
export default function Coupons(){
 const [items,setItems]=useState<any[]>([]);const [code,setCode]=useState("");const [value,setValue]=useState("");const [type,setType]=useState("FIXED");
 async function load(){const r=await fetch("/api/admin/coupons");setItems(await r.json())}useEffect(()=>{load()},[]);
 async function add(){const r=await fetch("/api/admin/coupons",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({code,discount_value:Number(value),discount_type:type})});if(!r.ok)alert(await r.text());else{setCode("");setValue("");load()}}
 return <main><h1 className="text-2xl font-bold">Coupons</h1><div className="mt-5 grid gap-2 sm:grid-cols-4"><input placeholder="Code" value={code} onChange={e=>setCode(e.target.value)} className="rounded-lg border px-3 py-2"/><select value={type} onChange={e=>setType(e.target.value)} className="rounded-lg border px-3 py-2"><option>FIXED</option><option>PERCENTAGE</option></select><input placeholder="Value" value={value} onChange={e=>setValue(e.target.value)} className="rounded-lg border px-3 py-2"/><button onClick={add} className="rounded-lg bg-black px-4 py-2 text-white">Add coupon</button></div><div className="mt-6 rounded-xl border bg-white">{items.map(c=><div key={c.id} className="flex justify-between border-b p-4"><b>{c.code}</b><span>{c.discount_type} · {c.discount_value}</span></div>)}</div></main>
}
