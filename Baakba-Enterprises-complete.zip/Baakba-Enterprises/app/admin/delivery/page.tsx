"use client";
import {useEffect,useState} from "react";
export default function Delivery(){
 const [zones,setZones]=useState<any[]>([]);const [name,setName]=useState("");const [fee,setFee]=useState("");const [mins,setMins]=useState("60");
 async function load(){const r=await fetch("/api/admin/delivery");setZones(await r.json())}useEffect(()=>{load()},[]);
 async function add(){const r=await fetch("/api/admin/delivery",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({name,fee:Number(fee),estimated_minutes:Number(mins)})});if(!r.ok)alert(await r.text());else{name&&setName("");setFee("");load()}}
 return <main><h1 className="text-2xl font-bold">Delivery zones</h1><div className="mt-5 grid gap-2 sm:grid-cols-4"><input placeholder="Zone" value={name} onChange={e=>setName(e.target.value)} className="rounded-lg border px-3 py-2"/><input placeholder="Fee NGN" value={fee} onChange={e=>setFee(e.target.value)} className="rounded-lg border px-3 py-2"/><input placeholder="Minutes" value={mins} onChange={e=>setMins(e.target.value)} className="rounded-lg border px-3 py-2"/><button onClick={add} className="rounded-lg bg-black px-4 py-2 text-white">Add zone</button></div><div className="mt-6 rounded-xl border bg-white">{zones.map(z=><div key={z.id} className="flex justify-between border-b p-4"><span>{z.name}</span><span>NGN {Number(z.fee).toLocaleString()} · {z.estimated_minutes} min</span></div>)}</div></main>
}
