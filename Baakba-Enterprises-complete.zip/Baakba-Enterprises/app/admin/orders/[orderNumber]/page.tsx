"use client";
import {useEffect,useState} from "react";
import {useParams,useRouter} from "next/navigation";

const statuses=["PROCESSING","READY_FOR_PICKUP","READY_FOR_DELIVERY","OUT_FOR_DELIVERY","DELIVERED","COMPLETED","CANCELLED","REFUNDED"];

export default function AdminOrderPage(){
 const {orderNumber}=useParams<{orderNumber:string}>(); const router=useRouter(); const [o,setO]=useState<any>(); const [status,setStatus]=useState(""); const [busy,setBusy]=useState(false);
 useEffect(()=>{fetch(`/api/admin/orders/${orderNumber}`).then(r=>r.json()).then(x=>{setO(x);setStatus(x.status||"")})},[orderNumber]);
 async function save(){setBusy(true);const r=await fetch(`/api/admin/orders/${orderNumber}`,{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify({status})});if(!r.ok)alert(await r.text());else {setO({...o,status});router.refresh()}setBusy(false)}
 if(!o)return <p>Loading...</p>;
 return <main><h1 className="text-2xl font-bold">Order {orderNumber}</h1><div className="mt-6 rounded-xl border bg-white p-5"><p>Status: <b>{o.status}</b></p><p className="mt-2">Total: NGN {Number(o.total_amount||0).toLocaleString()}</p><div className="mt-5 flex gap-2"><select value={status} onChange={e=>setStatus(e.target.value)} className="rounded-lg border px-3 py-2">{statuses.map(s=><option key={s}>{s}</option>)}</select><button disabled={busy} onClick={save} className="rounded-lg bg-black px-4 py-2 text-white">{busy?"Saving...":"Update"}</button></div></div></main>;
}
