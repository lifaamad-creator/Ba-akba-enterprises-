"use client";
import {useEffect,useState} from "react";
export default function Categories(){
 const [items,setItems]=useState<any[]>([]);const [name,setName]=useState("");const [busy,setBusy]=useState(false);
 async function load(){const r=await fetch("/api/admin/categories");setItems(await r.json())}useEffect(()=>{load()},[]);
 async function add(){if(!name.trim())return;setBusy(true);const r=await fetch("/api/admin/categories",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({name})});if(!r.ok)alert(await r.text());else{setName("");load()}setBusy(false)}
 async function disable(id:string){if(!confirm("Deactivate this category?"))return;await fetch(`/api/admin/categories/${id}`,{method:"DELETE"});load()}
 return <main><h1 className="text-2xl font-bold">Categories</h1><div className="mt-5 flex gap-2"><input value={name} onChange={e=>setName(e.target.value)} placeholder="Category name" className="rounded-lg border px-3 py-2"/><button onClick={add} disabled={busy} className="rounded-lg bg-black px-4 py-2 text-white">Add</button></div><div className="mt-6 overflow-hidden rounded-xl border bg-white">{items.map(x=><div key={x.id} className="flex justify-between border-b p-4"><span>{x.name}</span>{x.is_active&&<button onClick={()=>disable(x.id)} className="text-sm text-red-600">Deactivate</button>}</div>)}</div></main>
}
