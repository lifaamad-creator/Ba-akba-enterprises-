import {supabaseAdmin} from "@/lib/supabase";
import {formatNaira} from "@/lib/money";
export default async function Admin(){
 const sb=supabaseAdmin();
 const [{count:orders},{count:products}]=await Promise.all([
  sb.from("orders").select("*",{count:"exact",head:true}),
  sb.from("products").select("*",{count:"exact",head:true})
 ]);
 const {data:paid}=await sb.from("orders").select("total").eq("payment_status","SUCCESS");
 const sales=(paid??[]).reduce((s,o)=>s+Number(o.total),0);
 return <div className="container" style={{padding:"40px 0"}}><h1>Admin Dashboard</h1><p style={{color:"#64748b"}}>Operations overview for Ba'akba Enterprises.</p><div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16,marginTop:20}}>{[["Orders",orders??0],["Products",products??0],["Paid sales",formatNaira(sales)]].map(([a,b])=><div className="card" style={{padding:22}} key={String(a)}><small>{a}</small><h2>{b}</h2></div>)}</div><div className="card" style={{padding:22,marginTop:20}}><strong>Next admin modules</strong><p>Product CRUD, order management, delivery zones, coupons, banners and audit log should be protected by server-side ADMIN authorization before deployment.</p></div></div>
}