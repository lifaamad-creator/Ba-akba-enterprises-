export default function PrivacyPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-bold">Privacy Policy</h1>
      <p className="mt-4 text-gray-600">
        Ba&apos;akba Enterprises uses customer information only to provide accounts,
        process orders, payments, delivery or pickup, and improve the store.
      </p>
      <h2 className="mt-8 text-xl font-semibold">Payment information</h2>
      <p className="mt-2 text-gray-600">
        Card and bank payment details are handled by Paystack. Ba&apos;akba
        Enterprises does not store full card details.
      </p>
      <h2 className="mt-8 text-xl font-semibold">Your choices</h2>
      <p className="mt-2 text-gray-600">
        Contact the store to request corrections to your account information or
        ask questions about your data.
      </p>
    </main>
  );
}
