"use client";

export default function Error({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="text-2xl font-bold">Something went wrong</h1>
      <p className="mt-2 text-gray-600">Please try again.</p>
      <button onClick={() => reset()} className="mt-6 rounded-lg bg-black px-5 py-3 text-white">
        Try again
      </button>
    </main>
  );
}
