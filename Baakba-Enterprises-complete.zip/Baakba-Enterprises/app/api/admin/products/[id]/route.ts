import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { requireUser } from "@/lib/auth";
import { productSchema } from "@/lib/validation";

async function admin() {
  const user=await requireUser();
  const role=String(user.profile?.role ?? user.role ?? "").toUpperCase();
  if(role!=="ADMIN") throw new Error("FORBIDDEN");
}

export async function GET(_:Request,{params}:{params:Promise<{id:string}>}) {
  try { await admin(); const {id}=await params;
    const db=supabaseAdmin(); const {data,error}=await db.from("products").select("*").eq("id",id).single();
    if(error) return NextResponse.json({error:error.message},{status:404}); return NextResponse.json(data);
  } catch(e:any){return NextResponse.json({error:e.message},{status:e.message==="FORBIDDEN"?403:401});}
}

export async function PATCH(req:Request,{params}:{params:Promise<{id:string}>}) {
  try { await admin(); const {id}=await params; const body=await req.json();
    const parsed=productSchema.partial().safeParse(body); if(!parsed.success) return NextResponse.json({error:parsed.error.flatten()},{status:400});
    const db=supabaseAdmin(); const {data,error}=await db.from("products").update(parsed.data).eq("id",id).select().single();
    if(error) return NextResponse.json({error:error.message},{status:400}); return NextResponse.json(data);
  } catch(e:any){return NextResponse.json({error:e.message},{status:e.message==="FORBIDDEN"?403:401});}
}

export async function DELETE(_:Request,{params}:{params:Promise<{id:string}>}) {
  try { await admin(); const {id}=await params; const db=supabaseAdmin();
    const {error}=await db.from("products").update({is_active:false}).eq("id",id);
    if(error) return NextResponse.json({error:error.message},{status:400}); return NextResponse.json({ok:true});
  } catch(e:any){return NextResponse.json({error:e.message},{status:e.message==="FORBIDDEN"?403:401});}
}
