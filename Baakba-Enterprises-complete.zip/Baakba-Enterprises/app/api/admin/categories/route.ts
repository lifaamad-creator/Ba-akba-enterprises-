import {NextResponse} from "next/server";
import {supabaseAdmin} from "@/lib/supabase-admin";
import {requireAdmin} from "@/lib/admin";

export async function GET(){try{await requireAdmin();const {data,error}=await supabaseAdmin().from("categories").select("*").order("name");if(error)throw error;return NextResponse.json(data)}catch(e:any){return NextResponse.json({error:e.message},{status:e.message==="FORBIDDEN"?403:401})}}
export async function POST(req:Request){try{await requireAdmin();const b=await req.json();if(!b.name)return NextResponse.json({error:"Name required"},{status:400});const slug=String(b.slug||b.name).toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");const {data,error}=await supabaseAdmin().from("categories").insert({name:String(b.name).trim(),slug,is_active:b.is_active!==false}).select().single();if(error)throw error;return NextResponse.json(data,{status:201})}catch(e:any){return NextResponse.json({error:e.message},{status:400})}}
