import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { supabaseAdmin } from "@/lib/supabase-admin";

export async function POST(req:Request){
  try{
    const u=await requireUser(); const role=String(u.profile?.role ?? u.role ?? "").toUpperCase();
    if(role!=="ADMIN") return NextResponse.json({error:"Forbidden"},{status:403});
    const b=await req.json();
    const productId=String(b.productId||""); const delta=Number(b.delta); const reason=String(b.reason||"ADMIN_ADJUSTMENT");
    if(!productId || !Number.isInteger(delta) || delta===0) return NextResponse.json({error:"Invalid adjustment"},{status:400});
    const db=supabaseAdmin();
    const {data:p,error:e}=await db.from("products").select("stock_quantity").eq("id",productId).single();
    if(e||!p) return NextResponse.json({error:"Product not found"},{status:404});
    const next=Number(p.stock_quantity)+delta; if(next<0) return NextResponse.json({error:"Stock cannot be negative"},{status:400});
    const {error}=await db.from("products").update({stock_quantity:next}).eq("id",productId);
    if(error) return NextResponse.json({error:error.message},{status:400});
    await db.from("inventory_transactions").insert({product_id:productId,quantity:delta,transaction_type:"ADJUSTMENT",reason});
    return NextResponse.json({ok:true,stock_quantity:next});
  }catch(e:any){return NextResponse.json({error:e.message},{status:401});}
}
