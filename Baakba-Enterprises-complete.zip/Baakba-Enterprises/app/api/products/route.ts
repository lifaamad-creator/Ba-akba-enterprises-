import {NextResponse} from "next/server";
import {supabaseAdmin} from "@/lib/supabase-admin";

export async function GET(req:Request){
  const url=new URL(req.url), q=url.searchParams.get("q")?.trim()||"", category=url.searchParams.get("category")||"", sort=url.searchParams.get("sort")||"name";
  const db=supabaseAdmin();
  let query=db.from("products").select("id,name,slug,description,price,stock_quantity,unit,sku,category_id,is_active,product_images(url,sort_order)").eq("is_active",true);
  if(q) query=query.or(`name.ilike.%${q}%,description.ilike.%${q}%`);
  if(category) query=query.eq("category_id",category);
  query=sort==="price_asc"?query.order("price",{ascending:true}):sort==="price_desc"?query.order("price",{ascending:false}):query.order("name",{ascending:true});
  const {data,error}=await query.limit(100);
  if(error)return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json(data||[]);
}
