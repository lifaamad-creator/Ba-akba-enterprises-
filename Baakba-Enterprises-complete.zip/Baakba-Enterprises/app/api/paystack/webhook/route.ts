import {NextResponse} from "next/server";
import crypto from "crypto";
import {supabaseAdmin} from "@/lib/supabase";

export async function POST(req:Request){
 const raw=await req.text();
 const secret=process.env.PAYSTACK_SECRET_KEY;
 if(!secret) return NextResponse.json({error:"Not configured"},{status:500});
 const signature=req.headers.get("x-paystack-signature")??"";
 const expected=crypto.createHmac("sha512",secret).update(raw).digest("hex");
 if(!crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))) return NextResponse.json({error:"Invalid signature"},{status:401});
 const event=JSON.parse(raw);
 if(event.event!=="charge.success") return NextResponse.json({received:true});
 const reference=event.data?.reference;
 if(!reference) return NextResponse.json({received:true});
 const sb=supabaseAdmin();
 const {data,error}=await sb.rpc("confirm_order_payment",{p_reference:reference,p_provider_status:"SUCCESS"});
 if(error) return NextResponse.json({error:error.message},{status:500});
 return NextResponse.json({received:true,result:data});
}