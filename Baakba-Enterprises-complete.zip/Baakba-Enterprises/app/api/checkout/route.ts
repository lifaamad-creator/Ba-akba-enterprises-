import {NextResponse} from "next/server";
import {supabaseAdmin} from "@/lib/supabase";
import {checkoutSchema} from "@/lib/validation";

async function getUser(req:Request){
 const auth=req.headers.get("authorization");
 if(!auth?.startsWith("Bearer ")) return null;
 const token=auth.slice(7);
 const sb=supabaseAdmin();
 const {data}=await sb.auth.getUser(token);
 return data.user??null;
}

export async function POST(req:Request){
 try{
  const body=checkoutSchema.parse(await req.json());
  const user=await getUser(req);
  if(!user) return NextResponse.json({error:"Please sign in before checkout."},{status:401});
  const sb=supabaseAdmin();
  const {data:result,error}=await sb.rpc("create_checkout_order",{p_user_id:user.id,p_fulfillment_method:body.fulfillmentMethod,p_address_id:body.addressId??null,p_delivery_zone_id:body.deliveryZoneId??null,p_coupon_code:body.couponCode??null});
  if(error) return NextResponse.json({error:error.message},{status:400});
  const order=Array.isArray(result)?result[0]:result;
  if(!order?.id) return NextResponse.json({error:"Could not create order."},{status:400});
  const secret=process.env.PAYSTACK_SECRET_KEY;
  if(!secret) return NextResponse.json({error:"Paystack is not configured yet.",orderNumber:order.order_number},{status:503});
  const base=process.env.NEXT_PUBLIC_SITE_URL??"http://localhost:3000";
  const response=await fetch("https://api.paystack.co/transaction/initialize",{method:"POST",headers:{Authorization:`Bearer ${secret}`,"Content-Type":"application/json"},body:JSON.stringify({email:user.email,amount:Math.round(Number(order.total)*100),currency:"NGN",reference:order.payment_reference,callback_url:`${base}/checkout/confirm`})});
  const pay=await response.json();
  if(!response.ok||!pay.status) return NextResponse.json({error:pay.message??"Paystack initialization failed."},{status:502});
  await sb.from("payments").update({authorization_url:pay.data.authorization_url}).eq("reference",order.payment_reference);
  return NextResponse.json({orderNumber:order.order_number,authorization_url:pay.data.authorization_url,reference:order.payment_reference});
 }catch(e:any){return NextResponse.json({error:e?.message??"Invalid checkout request."},{status:400})}
}