import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    ok: true,
    service: "baakba-enterprises",
    timestamp: new Date().toISOString(),
  });
}
