create index if not exists idx_products_category_active on public.products(category_id, is_active);
create index if not exists idx_orders_status_created_at on public.orders(status, created_at desc);
create index if not exists idx_coupons_code_active on public.coupons(code, is_active);
create index if not exists idx_banners_active on public.homepage_banners(is_active);
create index if not exists idx_delivery_zones_active on public.delivery_zones(is_active);
