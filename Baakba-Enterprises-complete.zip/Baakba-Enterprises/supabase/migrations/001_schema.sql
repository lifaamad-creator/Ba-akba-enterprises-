create extension if not exists pgcrypto;

create type public.app_role as enum ('CUSTOMER','ADMIN');
create type public.fulfillment_method as enum ('DELIVERY','PICKUP');
create type public.order_status as enum ('PENDING_PAYMENT','PAYMENT_CONFIRMED','PROCESSING','READY_FOR_PICKUP','READY_FOR_DELIVERY','OUT_FOR_DELIVERY','DELIVERED','COMPLETED','CANCELLED','REFUNDED');
create type public.payment_status as enum ('PENDING','SUCCESS','FAILED','REFUNDED','PARTIALLY_REFUNDED');

create table public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '',
 phone text,
 role public.app_role not null default 'CUSTOMER',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.categories(
 id uuid primary key default gen_random_uuid(),
 name text not null,
 slug text not null unique,
 description text,
 sort_order integer not null default 0,
 active boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.products(
 id uuid primary key default gen_random_uuid(),
 category_id uuid references public.categories(id) on delete set null,
 name text not null,
 slug text not null unique,
 sku text not null unique,
 description text,
 price numeric(12,2) not null check(price>=0),
 compare_at_price numeric(12,2) check(compare_at_price is null or compare_at_price>=price),
 selling_unit text not null,
 quantity_per_unit numeric(12,3),
 stock_quantity integer not null default 0 check(stock_quantity>=0),
 low_stock_threshold integer not null default 5 check(low_stock_threshold>=0),
 image_url text,
 active boolean not null default true,
 featured boolean not null default false,
 bestseller boolean not null default false,
 new_arrival boolean not null default false,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index products_category_idx on public.products(category_id);
create index products_active_idx on public.products(active);
create index products_name_idx on public.products(name);

create table public.addresses(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 full_name text not null,
 phone text not null,
 address_line text not null,
 area text not null,
 city text not null default 'Jos',
 state text not null default 'Plateau',
 delivery_instructions text,
 is_default boolean not null default false,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index addresses_user_idx on public.addresses(user_id);

create table public.delivery_zones(
 id uuid primary key default gen_random_uuid(),
 name text not null,
 state text not null default 'Plateau',
 city text not null default 'Jos',
 area text not null,
 delivery_fee numeric(12,2) not null check(delivery_fee>=0),
 estimated_delivery text not null default 'Same day',
 active boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.carts(
 id uuid primary key default gen_random_uuid(),
 user_id uuid unique references public.profiles(id) on delete cascade,
 session_key text unique,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 check(user_id is not null or session_key is not null)
);

create table public.cart_items(
 id uuid primary key default gen_random_uuid(),
 cart_id uuid not null references public.carts(id) on delete cascade,
 product_id uuid not null references public.products(id) on delete restrict,
 quantity integer not null check(quantity>0),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 unique(cart_id,product_id)
);

create table public.wishlists(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null unique references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table public.wishlist_items(
 id uuid primary key default gen_random_uuid(),
 wishlist_id uuid not null references public.wishlists(id) on delete cascade,
 product_id uuid not null references public.products(id) on delete cascade,
 created_at timestamptz not null default now(),
 unique(wishlist_id,product_id)
);

create table public.orders(
 id uuid primary key default gen_random_uuid(),
 order_number text not null unique,
 user_id uuid not null references public.profiles(id) on delete restrict,
 fulfillment_method public.fulfillment_method not null,
 address_snapshot jsonb,
 pickup_snapshot jsonb,
 delivery_zone_id uuid references public.delivery_zones(id) on delete set null,
 subtotal numeric(12,2) not null check(subtotal>=0),
 discount numeric(12,2) not null default 0 check(discount>=0),
 delivery_fee numeric(12,2) not null default 0 check(delivery_fee>=0),
 total numeric(12,2) not null check(total>=0),
 currency text not null default 'NGN',
 status public.order_status not null default 'PENDING_PAYMENT',
 payment_status public.payment_status not null default 'PENDING',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index orders_user_idx on public.orders(user_id);
create index orders_status_idx on public.orders(status);
create index orders_created_idx on public.orders(created_at desc);

create table public.order_items(
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null references public.orders(id) on delete cascade,
 product_id uuid not null references public.products(id) on delete restrict,
 product_name text not null,
 sku text not null,
 selling_unit text not null,
 quantity integer not null check(quantity>0),
 unit_price numeric(12,2) not null check(unit_price>=0),
 subtotal numeric(12,2) not null check(subtotal>=0),
 created_at timestamptz not null default now()
);
create index order_items_order_idx on public.order_items(order_id);

create table public.payments(
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null unique references public.orders(id) on delete restrict,
 provider text not null default 'PAYSTACK',
 reference text not null unique,
 authorization_url text,
 amount numeric(12,2) not null check(amount>=0),
 currency text not null default 'NGN',
 status public.payment_status not null default 'PENDING',
 metadata jsonb,
 paid_at timestamptz,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.inventory_transactions(
 id uuid primary key default gen_random_uuid(),
 product_id uuid not null references public.products(id) on delete restrict,
 order_id uuid references public.orders(id) on delete set null,
 previous_quantity integer not null,
 quantity_changed integer not null,
 new_quantity integer not null,
 reason text not null,
 actor_id uuid references public.profiles(id) on delete set null,
 created_at timestamptz not null default now()
);

create table public.coupons(
 id uuid primary key default gen_random_uuid(),
 code text not null unique,
 discount_type text not null check(discount_type in ('PERCENTAGE','FIXED')),
 discount_value numeric(12,2) not null check(discount_value>=0),
 minimum_order_amount numeric(12,2) not null default 0 check(minimum_order_amount>=0),
 maximum_discount numeric(12,2),
 usage_limit integer,
 per_customer_limit integer,
 starts_at timestamptz,
 ends_at timestamptz,
 active boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.coupon_usages(
 id uuid primary key default gen_random_uuid(),
 coupon_id uuid not null references public.coupons(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 order_id uuid not null unique references public.orders(id) on delete cascade,
 created_at timestamptz not null default now()
);

create table public.reviews(
 id uuid primary key default gen_random_uuid(),
 product_id uuid not null references public.products(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 order_id uuid not null references public.orders(id) on delete cascade,
 rating integer not null check(rating between 1 and 5),
 title text,
 body text,
 moderation_status text not null default 'PENDING' check(moderation_status in ('PENDING','APPROVED','REJECTED')),
 created_at timestamptz not null default now(),
 unique(product_id,user_id,order_id)
);

create table public.homepage_banners(
 id uuid primary key default gen_random_uuid(),
 title text not null,
 subtitle text,
 image_url text not null,
 link_url text,
 display_order integer not null default 0,
 active boolean not null default true,
 starts_at timestamptz,
 ends_at timestamptz,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.notifications(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 type text not null,
 title text not null,
 body text not null,
 read_at timestamptz,
 created_at timestamptz not null default now()
);

create table public.admin_activity_logs(
 id uuid primary key default gen_random_uuid(),
 admin_id uuid not null references public.profiles(id) on delete restrict,
 action text not null,
 entity_type text not null,
 entity_id uuid,
 metadata jsonb,
 created_at timestamptz not null default now()
);

create table public.store_settings(
 id boolean primary key default true,
 store_name text not null default 'Ba''akba Enterprises',
 phone text,
 email text,
 address text,
 currency text not null default 'NGN',
 logo_url text,
 business_hours jsonb,
 updated_at timestamptz not null default now()
);

create table public.pickup_settings(
 id boolean primary key default true,
 enabled boolean not null default true,
 store_name text not null default 'Ba''akba Enterprises',
 address text,
 opening_hours jsonb,
 instructions text,
 preparation_minutes integer not null default 60 check(preparation_minutes>=0),
 updated_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='ADMIN'); $$;

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.addresses enable row level security;
alter table public.delivery_zones enable row level security;
alter table public.carts enable row level security;
alter table public.cart_items enable row level security;
alter table public.wishlists enable row level security;
alter table public.wishlist_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.reviews enable row level security;
alter table public.notifications enable row level security;
alter table public.homepage_banners enable row level security;
alter table public.store_settings enable row level security;
alter table public.pickup_settings enable row level security;
alter table public.inventory_transactions enable row level security;
alter table public.coupons enable row level security;
alter table public.coupon_usages enable row level security;
alter table public.admin_activity_logs enable row level security;

create policy "public read active products" on public.products for select using(active=true or public.is_admin());
create policy "public read active categories" on public.categories for select using(active=true or public.is_admin());
create policy "public read active zones" on public.delivery_zones for select using(active=true or public.is_admin());
create policy "public read banners" on public.homepage_banners for select using(active=true or public.is_admin());
create policy "public read settings" on public.store_settings for select using(true);
create policy "public read pickup settings" on public.pickup_settings for select using(true);

create policy "own profile" on public.profiles for select using(id=auth.uid() or public.is_admin());
create policy "own addresses" on public.addresses for all using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());
create policy "own carts" on public.carts for all using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());
create policy "own cart items" on public.cart_items for all using(exists(select 1 from public.carts c where c.id=cart_id and (c.user_id=auth.uid() or public.is_admin()))) with check(exists(select 1 from public.carts c where c.id=cart_id and (c.user_id=auth.uid() or public.is_admin())));
create policy "own wishlist" on public.wishlists for all using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());
create policy "own wishlist items" on public.wishlist_items for all using(exists(select 1 from public.wishlists w where w.id=wishlist_id and (w.user_id=auth.uid() or public.is_admin()))) with check(exists(select 1 from public.wishlists w where w.id=wishlist_id and (w.user_id=auth.uid() or public.is_admin())));
create policy "own orders" on public.orders for select using(user_id=auth.uid() or public.is_admin());
create policy "own order items" on public.order_items for select using(exists(select 1 from public.orders o where o.id=order_id and (o.user_id=auth.uid() or public.is_admin())));
create policy "own payments" on public.payments for select using(exists(select 1 from public.orders o where o.id=order_id and (o.user_id=auth.uid() or public.is_admin())));
create policy "own notifications" on public.notifications for all using(user_id=auth.uid() or public.is_admin()) with check(user_id=auth.uid() or public.is_admin());
create policy "reviews read" on public.reviews for select using(moderation_status='APPROVED' or user_id=auth.uid() or public.is_admin());
create policy "reviews own write" on public.reviews for insert with check(user_id=auth.uid());
create policy "admin inventory" on public.inventory_transactions for all using(public.is_admin()) with check(public.is_admin());
create policy "admin coupons" on public.coupons for all using(public.is_admin()) with check(public.is_admin());
create policy "admin coupon usage" on public.coupon_usages for select using(user_id=auth.uid() or public.is_admin());
create policy "admin logs" on public.admin_activity_logs for select using(admin_id=auth.uid() or public.is_admin());

create or replace function public.create_checkout_order(
 p_user_id uuid,
 p_fulfillment_method public.fulfillment_method,
 p_address_id uuid default null,
 p_delivery_zone_id uuid default null,
 p_coupon_code text default null
) returns table(id uuid, order_number text, total numeric, payment_reference text)
language plpgsql security definer set search_path=public
as $$
declare
 c record; item record; subtotal numeric:=0; delivery numeric:=0; discount numeric:=0; total numeric; ord uuid; num text; pref text; coupon record;
begin
 if p_user_id <> auth.uid() and auth.uid() is not null then raise exception 'Unauthorized'; end if;
 for item in
   select ci.quantity,p.id product_id,p.name,p.sku,p.selling_unit,p.price,p.stock_quantity
   from carts c join cart_items ci on ci.cart_id=c.id join products p on p.id=ci.product_id
   where c.user_id=p_user_id and p.active=true
   for update of p
 loop
   if item.stock_quantity < item.quantity then raise exception 'Insufficient stock for %', item.name; end if;
   subtotal := subtotal + item.price*item.quantity;
 end loop;
 if subtotal=0 then raise exception 'Cart is empty'; end if;
 if p_fulfillment_method='DELIVERY' then
   if p_address_id is null or p_delivery_zone_id is null then raise exception 'Delivery address and zone are required'; end if;
   select dz.delivery_fee into delivery from delivery_zones dz where dz.id=p_delivery_zone_id and dz.active=true;
   if delivery is null then raise exception 'Invalid delivery zone'; end if;
 else
   if not exists(select 1 from pickup_settings where enabled=true) then raise exception 'Pickup is unavailable'; end if;
 end if;
 if p_coupon_code is not null and trim(p_coupon_code)<>'' then
   select * into coupon from coupons where upper(code)=upper(trim(p_coupon_code)) and active=true and (starts_at is null or now()>=starts_at) and (ends_at is null or now()<=ends_at) for update;
   if coupon.id is null then raise exception 'Invalid coupon'; end if;
   if subtotal < coupon.minimum_order_amount then raise exception 'Minimum order amount not reached'; end if;
   if coupon.discount_type='PERCENTAGE' then discount:=least(subtotal,subtotal*coupon.discount_value/100); else discount:=least(subtotal,coupon.discount_value); end if;
   if coupon.maximum_discount is not null then discount:=least(discount,coupon.maximum_discount); end if;
 end if;
 total:=greatest(0,subtotal-discount+delivery);
 num:='BAK-'||to_char(now(),'YYMMDDHH24MISS')||'-'||upper(substr(encode(gen_random_bytes(4),'hex'),1,6));
 pref:='BAK_'||replace(gen_random_uuid()::text,'-','');
 insert into orders(order_number,user_id,fulfillment_method,address_snapshot,pickup_snapshot,delivery_zone_id,subtotal,discount,delivery_fee,total)
 values(num,p_user_id,p_fulfillment_method,
   case when p_address_id is null then null else (select to_jsonb(a) from addresses a where a.id=p_address_id and a.user_id=p_user_id) end,
   case when p_fulfillment_method='PICKUP' then (select to_jsonb(ps) from pickup_settings ps where id=true) else null end,
   p_delivery_zone_id,subtotal,discount,delivery,total) returning orders.id into ord;
 insert into order_items(order_id,product_id,product_name,sku,selling_unit,quantity,unit_price,subtotal)
 select ord,p.id,p.name,p.sku,p.selling_unit,ci.quantity,p.price,p.price*ci.quantity
 from carts c join cart_items ci on ci.cart_id=c.id join products p on p.id=ci.product_id where c.user_id=p_user_id;
 insert into payments(order_id,reference,amount,currency) values(ord,pref,total,'NGN');
 if p_coupon_code is not null and trim(p_coupon_code)<>'' then
   insert into coupon_usages(coupon_id,user_id,order_id) values(coupon.id,p_user_id,ord);
 end if;
 return query select ord,num,total,pref;
end $$;

create or replace function public.confirm_order_payment(p_reference text,p_provider_status text)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare pay record; ord record; item record;
begin
 select * into pay from payments where reference=p_reference for update;
 if pay.id is null then raise exception 'Payment reference not found'; end if;
 if pay.status='SUCCESS' then return jsonb_build_object('status','already_confirmed'); end if;
 if p_provider_status<>'SUCCESS' then update payments set status='FAILED',updated_at=now() where id=pay.id; update orders set payment_status='FAILED',updated_at=now() where id=pay.order_id; return jsonb_build_object('status','failed'); end if;
 select * into ord from orders where id=pay.order_id for update;
 if pay.amount<>ord.total or pay.currency<>'NGN' then raise exception 'Payment amount/currency mismatch'; end if;
 for item in select oi.product_id,oi.quantity,p.stock_quantity,p.name from order_items oi join products p on p.id=oi.product_id where oi.order_id=ord.id for update of p loop
   if item.stock_quantity < item.quantity then raise exception 'Insufficient stock for %',item.name; end if;
   update products set stock_quantity=stock_quantity-item.quantity,updated_at=now() where id=item.product_id;
   insert into inventory_transactions(product_id,order_id,previous_quantity,quantity_changed,new_quantity,reason) values(item.product_id,ord.id,item.stock_quantity,-item.quantity,item.stock_quantity-item.quantity,'ORDER_PAYMENT');
 end loop;
 update payments set status='SUCCESS',paid_at=now(),updated_at=now() where id=pay.id;
 update orders set payment_status='SUCCESS',status='PAYMENT_CONFIRMED',updated_at=now() where id=ord.id;
 delete from cart_items where cart_id in(select id from carts where user_id=ord.user_id);
 return jsonb_build_object('status','confirmed','order_id',ord.id);
end $$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public
as $$ begin insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','')); return new; end $$;

create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

insert into public.store_settings(id,store_name,currency) values(true,'Ba''akba Enterprises','NGN') on conflict(id) do nothing;
insert into public.pickup_settings(id,enabled,store_name,instructions) values(true,true,'Ba''akba Enterprises','Bring your order number when collecting your groceries.') on conflict(id) do nothing;
