insert into categories(name,slug,description,sort_order) values
('Rice & Grains','rice-grains','Rice, beans and everyday grains',1),
('Pasta & Noodles','pasta-noodles','Pasta, spaghetti and noodles',2),
('Cooking Oils','cooking-oils','Vegetable oils and cooking fats',3),
('Drinks','drinks','Soft drinks, water and beverages',4),
('Snacks','snacks','Biscuits, sweets and quick snacks',5),
('Canned Foods','canned-foods','Canned and packaged foods',6),
('Cereals','cereals','Breakfast cereals and oats',7),
('Household','household','Cleaning and household essentials',8)
on conflict(slug) do nothing;

insert into products(category_id,name,slug,sku,description,price,selling_unit,stock_quantity,featured,new_arrival)
select id,'Premium Long Grain Rice','premium-long-grain-rice','BAK-RICE-001','Everyday long grain rice.',48000,'25kg',20,true,true from categories where slug='rice-grains'
on conflict(sku) do nothing;
insert into products(category_id,name,slug,sku,description,price,selling_unit,stock_quantity,featured)
select id,'Spaghetti','spaghetti-500g','BAK-PASTA-001','500g spaghetti pack.',1800,'pack',80,true from categories where slug='pasta-noodles'
on conflict(sku) do nothing;
insert into products(category_id,name,slug,sku,description,price,selling_unit,stock_quantity)
select id,'Vegetable Oil','vegetable-oil-1l','BAK-OIL-001','1 litre cooking oil.',4200,'bottle',50 from categories where slug='cooking-oils'
on conflict(sku) do nothing;
insert into products(category_id,name,slug,sku,description,price,selling_unit,stock_quantity)
select id,'Bottled Water','bottled-water','BAK-DRINK-001','75cl bottled water.',500,'bottle',120 from categories where slug='drinks'
on conflict(sku) do nothing;

insert into delivery_zones(name,state,city,area,delivery_fee,estimated_delivery) values
('Central Jos North','Plateau','Jos','Central Jos North',1500,'Same day'),
('Tudun Wada','Plateau','Jos','Tudun Wada',1800,'Same day'),
('Angwan Rogo','Plateau','Jos','Angwan Rogo',1800,'Same day'),
('University Area','Plateau','Jos','University Area',2000,'Same day')
on conflict do nothing;
