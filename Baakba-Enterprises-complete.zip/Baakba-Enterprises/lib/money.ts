export function formatNaira(amount: number | string) {
  const value = Number(amount || 0);
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 2,
  }).format(value);
}

export function toKobo(naira: number) {
  return Math.round(naira * 100);
}
