import { requireUser } from "@/lib/auth";

export async function requireAdmin() {
  const user = await requireUser();
  const role = String(user.profile?.role ?? user.role ?? "").toUpperCase();
  if (role !== "ADMIN") throw new Error("FORBIDDEN");
  return user;
}
