import { z } from "zod";

export const cartItemSchema = z.object({
  productId: z.string().uuid(),
  variantId: z.string().uuid().nullable().optional(),
  quantity: z.number().int().min(1).max(1000),
});

export const checkoutSchema = z.object({
  fulfillment: z.enum(["DELIVERY", "PICKUP"]),
  addressId: z.string().uuid().nullable().optional(),
  couponCode: z.string().trim().max(64).optional().or(z.literal("")),
});

export const productSchema = z.object({
  name: z.string().trim().min(2).max(160),
  slug: z.string().trim().min(2).max(180),
  description: z.string().max(5000).optional().or(z.literal("")),
  category_id: z.string().uuid().nullable().optional(),
  price: z.number().nonnegative(),
  stock_quantity: z.number().int().nonnegative(),
  unit: z.string().trim().min(1).max(40),
  sku: z.string().trim().max(80).optional().or(z.literal("")),
  is_active: z.boolean().default(true),
});

export const addressSchema = z.object({
  label: z.string().trim().min(1).max(60),
  recipient_name: z.string().trim().min(2).max(120),
  phone: z.string().trim().min(7).max(30),
  address_line1: z.string().trim().min(3).max(200),
  address_line2: z.string().trim().max(200).optional().or(z.literal("")),
  city: z.string().trim().min(2).max(100),
  state: z.string().trim().min(2).max(100),
  landmark: z.string().trim().max(200).optional().or(z.literal("")),
});
