# Ba'akba Enterprises — Start Here

This is the complete organized source package for the Ba'akba Enterprises grocery e-commerce app.

## Project folders

- `app/` — customer pages, admin pages, API routes
- `components/` — reusable UI components
- `lib/` — authentication, validation, money, admin helpers, etc.
- `public/` — public assets
- `supabase/` — database schema and migrations
- `README.md` — full setup/deployment notes
- `.env.example` — environment variable template (if included)
- `RELEASE.json` — release information

## Phone-only setup

The easiest route is to upload this project to GitHub and import the repository into a cloud coding service such as Replit. You do not need Node.js installed on your phone.

## Before launch

1. Create/configure the Supabase project.
2. Apply the SQL migrations in `supabase/migrations/` in order.
3. Add the required Supabase and Paystack environment variables.
4. Use Paystack test mode first.
5. Run type checking and a production build in the cloud environment.
6. Test registration, products, cart, checkout, Paystack payment, orders, pickup, delivery, admin actions, inventory, coupons and reviews.
7. Only after staging tests pass should live Paystack credentials be used.

Never expose `SUPABASE_SERVICE_ROLE_KEY` or `PAYSTACK_SECRET_KEY` to the browser.
