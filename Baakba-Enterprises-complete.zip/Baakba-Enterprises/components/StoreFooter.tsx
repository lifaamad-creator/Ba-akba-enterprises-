export default function StoreFooter() {
  return (
    <footer className="border-t mt-12">
      <div className="mx-auto max-w-6xl px-4 py-8 text-sm text-gray-600 flex flex-col gap-3 sm:flex-row sm:justify-between">
        <span>© {new Date().getFullYear()} Ba&apos;akba Enterprises</span>
        <div className="flex gap-4">
          <a href="/privacy" className="hover:underline">Privacy</a>
          <a href="/terms" className="hover:underline">Terms</a>
        </div>
      </div>
    </footer>
  );
}
