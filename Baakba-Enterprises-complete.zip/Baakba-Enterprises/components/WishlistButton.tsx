"use client";
import {useState} from "react";
export default function WishlistButton({productId}:{productId:string}){const [busy,setBusy]=useState(false);async function add(){setBusy(true);const r=await fetch("/api/wishlist",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({productId})});if(!r.ok)alert("Please log in to use your wishlist.");setBusy(false)}return <button disabled={busy} onClick={add} className="rounded-lg border px-4 py-2 text-sm">{busy?"Saving...":"♡ Wishlist"}</button>}
